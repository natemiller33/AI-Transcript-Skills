---
name: youtube-transcript
description: >
  Download and save the full transcript of any YouTube video as a clean, readable
  markdown file. Use this skill whenever the user provides a YouTube URL and asks
  for a transcript, captions, or text version of the video — even if they just say
  "get the transcript", "extract the text from this video", "what does this video say",
  or pastes a youtube.com or youtu.be link and asks for the content. Also trigger when
  the user wants to summarize, analyze, or search the content of a YouTube video,
  since that requires the transcript first.
---

# YouTube Transcript Skill

Save the captions of a YouTube video as a clean, readable markdown file.

## How it works

`scripts/get_transcript.py` uses only the Python standard library, so it runs on the
macOS system Python 3.9 with nothing installed: no yt-dlp, no browser cookies, no
keychain prompt. It asks YouTube's player API for the caption tracks the way the
YouTube Android app does (the same request the open-source youtube-transcript-api
library makes), downloads the chosen track as JSON, and joins it into paragraphs.

If YouTube refuses that request, the browser fallback below gets the same captions
from the YouTube player in a real browser.

Do not use yt-dlp with `--cookies-from-browser chrome`. On macOS it can wait on a
hidden keychain prompt and hang for minutes.

## Workflow

### Step 1: Get the URL

If the user hasn't provided a URL, ask for it. Any form works: `youtube.com/watch?v=`,
`youtu.be/`, `/shorts/`, `/live/`, `/embed/`, or a bare 11-character video ID.

### Step 2: Decide where to save

Save into the folder the user names, or the folder of the project the transcript is
for. Ask if that is unclear. Always pass the folder; the script's default is the
current folder.

### Step 3: Run the script

```bash
python3 "<skill_dir>/scripts/get_transcript.py" "<youtube_url>" "<output_folder>"
```

Add `--lang <code>` (for example `--lang es`) for a video in another language. A run
takes a few seconds and prints the saved path, the word count, and how far the
captions run against the video's length.

### Step 4: Act on the exit code

| Exit | Meaning | What to do |
|---|---|---|
| 0 | Saved | Check the "Captions run to X of Y" line. If X is more than 10 percent short of Y, tell the user the transcript may be partial. |
| 2 | Video unavailable | Tell the user: private, removed, age-restricted or members-only. The fallback will not help. |
| 3 | No captions in that language | The message lists the languages available. Rerun with `--lang`, or tell the user the video has no captions. |
| 4 or 5 | YouTube refused the command-line request | Use the browser fallback. Do not rerun the script in a loop; repeated requests earn a longer block. |
| 1 | Anything else | Read the message. "did not contain an API key" or a JSON error means YouTube changed something: use the browser fallback, and tell the user the script needs the maintenance step below. |

### Step 5: Present the file

Show the user the saved file (`present_files` in Cowork, a link in Claude Code) with
one line on what was saved: title, length, word count.

## Browser fallback

Use this when the script exits 4 or 5, or YouTube has changed something. It needs a
browser tool that can run JavaScript in a page. Tested on 2026-10-24 in the Claude Code
Desktop in-app browser, on auto-generated and human-made captions; Claude in Chrome
should work the same way but is untested. Each step returns within about 35 seconds,
under the browser tool's time limit.

The caption URL listed in the page returns an empty file when fetched on its own,
because YouTube now attaches a token that only its player generates. So these steps
make the player load the captions, then re-request the exact URL the player used,
from inside the page.

1. Open `https://www.youtube.com/watch?v=<VIDEO_ID>` in the browser.
2. Run this, with the video ID and language filled in:

   ```js
   const VID = 'VIDEO_ID', LANG = 'en';
   const sleep = ms => new Promise(r => setTimeout(r, ms));
   // Record caption requests as they happen; YouTube clears the browser's request list every few seconds
   window.__ytCapUrls = window.__ytCapUrls || [];
   if (!window.__ytObs) {
     window.__ytObs = new PerformanceObserver(l => l.getEntries().forEach(e => { if (e.name.includes('/api/timedtext')) window.__ytCapUrls.push(e.name); }));
     window.__ytObs.observe({ type: 'resource', buffered: true });
   }
   let p = null;
   for (let i = 0; i < 40 && !(p && p.getVideoData); i++) { p = document.getElementById('movie_player'); await sleep(250); }
   const v = p.querySelector('video'); v.muted = true; p.mute(); p.playVideo();
   // Let a pre-roll ad play out muted, for up to 25 s. Never click Skip: a scripted click can freeze the ad
   for (let i = 0; i < 50 && p.classList.contains('ad-showing'); i++) { v.play().catch(() => {}); await sleep(500); }
   if (p.classList.contains('ad-showing')) { `AD_PLAYING at ${Math.round(v.currentTime)} of ${Math.round(v.duration)} s`; } else {
     await sleep(1500);
     p.loadModule('captions');
     await sleep(1000);
     // Human-made captions first, then auto-generated
     const tracks = p.getOption('captions', 'tracklist') || [];
     const pick = tracks.find(t => t.languageCode === LANG && t.kind !== 'asr') || tracks.find(t => t.languageCode === LANG) || { languageCode: LANG, kind: 'asr' };
     p.setOption('captions', 'track', pick);
     for (let i = 0; i < 20 && !window.__ytCapUrls.some(u => u.includes('v=' + VID)); i++) await sleep(250);
     window.__ytCapUrls.some(u => u.includes('v=' + VID)) ? 'CAPTIONS_LOADED' : 'NO_CAPTION_REQUEST languages=' + tracks.map(t => t.languageCode).join(',');
   }
   ```

   - `CAPTIONS_LOADED`: go on to step 3.
   - `AD_PLAYING at X of Y s`: an ad is still running. Run step 2 again on the same
     page, up to three more times. Reload the page and start again from step 2
     instead if Y is over 60 (a long ad takes many runs to play out), if X has not
     moved since the last run, or if the ad is still running after the third run.
     Ads come and go between page loads.
   - `NO_CAPTION_REQUEST`: the languages listed are the captions this video has. If
     the one you asked for is missing, rerun with a listed code or tell the user. If
     the list is empty, the video has no captions. If the language is listed, the
     player was slow: run step 2 once more.

3. Run this, with the video ID filled in, to fetch the captions and read the title,
   channel, length and caption type:

   ```js
   const VID = 'VIDEO_ID';
   const p = document.getElementById('movie_player'); p.pauseVideo();
   const hits = window.__ytCapUrls.filter(u => u.includes('v=' + VID));
   const u = new URL(hits[hits.length - 1]); u.searchParams.set('fmt', 'json3');
   const body = await (await fetch(u, { credentials: 'include' })).text();
   const events = body ? JSON.parse(body).events || [] : [];
   const text = events.map(e => (e.segs || []).map(s => s.utf8 || '').join('')).join(' ').replace(/\s+/g, ' ').trim();
   window.__ytChars = Array.from(text);
   const end = events.filter(e => e.segs).reduce((m, e) => Math.max(m, (e.tStartMs || 0) + (e.dDurationMs || 0)), 0);
   const d = p.getVideoData(), track = p.getOption('captions', 'track') || {};
   JSON.stringify({ title: d.title, channel: d.author, lengthSeconds: Math.round(p.getDuration()), coveredSeconds: Math.round(end / 1000), captions: track.displayName || track.languageName || '', chars: window.__ytChars.length })
   ```

   If `chars` is 0, the fetch failed: reload the page and start again from step 2.

4. Save two files in a scratch or temp folder, never in the user's project folder.
   Copy values exactly as the tool shows them, surrounding quotes and backslashes
   included. Do not decode or tidy anything: the script does that, and checks the
   text against `chars`.
   - **Meta file:** the step 3 result.
   - **Text file:** the text, read out in slices. Run
     `window.__ytChars.slice(0, 20000).join('')`, then
     `window.__ytChars.slice(20000, 40000).join('')`, and so on until `chars` is
     covered. Put each returned value on its own line, in order. If the tool shows
     plain text without surrounding quotes, write the slices back to back instead,
     with no line breaks between them.
5. Format and save it with the same script, which makes no network calls in this mode:

   ```bash
   python3 "<skill_dir>/scripts/get_transcript.py" "<youtube_url>" "<output_folder>" --text-file "<text_file>" --meta-file "<meta_file>"
   ```

   It prints the same lines as a normal run, so check "Captions run to" as in
   Workflow Step 4.
   Exit 6 means the text file does not match what the browser returned: rewrite it
   from the slices and run the script again.

Then present the file as in Step 5.

## Maintenance

The command-line method depends on YouTube continuing to serve captions to the Android
app identity. If exits 4 or 5 start happening on every video, the usual fix is a newer
`clientVersion` in `ANDROID_CLIENT` at the top of the script. The youtube-transcript-api
project on GitHub keeps a working value in `youtube_transcript_api/_settings.py`. Make
the change in the skill on claude.ai, not in a local copy, which a sync overwrites.

## Output format

- File name `YYYY-MM-DD <Video title>.md`, dated the day it was retrieved. `:` and `|`
  become ` - `; emoji and characters that break file names or Obsidian links are
  removed. An existing file is never overwritten: a ` (2)` suffix is added instead.
- An H1 title, a one-line purpose statement, then the video URL, channel, length,
  caption track and retrieval date.
- The transcript as prose paragraphs of about six sentences each.

## Notes on quality

Auto-generated captions mishear words, especially names and jargon, and can drop
words. The transcript is good for search, summary and reference; check any quote
against the video before it goes into something the user will send to anyone.
