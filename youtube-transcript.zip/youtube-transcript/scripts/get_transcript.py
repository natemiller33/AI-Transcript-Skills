#!/usr/bin/env python3
"""
get_transcript.py
Usage:
  python3 get_transcript.py <youtube_url_or_id> <output_folder> [--lang en]
  python3 get_transcript.py <youtube_url_or_id> <output_folder> --text-file FILE --meta-file FILE

Fetches a YouTube video's captions and saves them as a dated markdown file.
Standard library only: runs on the macOS system Python 3.9 with nothing installed,
no yt-dlp, no browser cookies.

The second form makes no network calls. It formats caption text captured in a
browser (the fallback in SKILL.md) into the same markdown file. Both files may hold
the browser tool's values exactly as it displays them, quotes and escapes included.

Exit codes:
  0  saved
  1  usage or unexpected error
  2  video unavailable (private, removed, age-restricted, members-only)
  3  no captions in the requested language (available languages are printed)
  4  YouTube wants a browser-generated token for these captions: use the browser fallback
  5  rate-limited or blocked by YouTube: use the browser fallback
  6  browser mode only: the text file does not match what the browser returned
"""

import argparse
import http.cookiejar
import json
import re
import sys
import unicodedata
import urllib.error
import urllib.request
from datetime import date
from pathlib import Path

# The player request identifies itself as the YouTube Android app, the same
# request the youtube-transcript-api library makes. If YouTube starts refusing
# it, that library's youtube_transcript_api/_settings.py has a current
# clientVersion.
ANDROID_CLIENT = {"clientName": "ANDROID", "clientVersion": "20.10.38", "androidSdkVersion": 30, "hl": "en"}
ANDROID_UA = "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"
DESKTOP_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
)


class Stop(Exception):
    """A failure with a message for the user and an exit code."""

    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def video_id(arg: str) -> str:
    """Accept watch, youtu.be, shorts, embed and live URLs, or a bare 11-character ID."""
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/|live/)([A-Za-z0-9_-]{11})", arg)
    if m:
        return m.group(1)
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", arg):
        return arg
    raise Stop(1, f"Could not find a YouTube video ID in: {arg}")


def fetch(opener, url, data=None, headers=None) -> str:
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with opener.open(req, timeout=30) as r:
            return r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        if e.code == 429:
            raise Stop(5, "YouTube returned HTTP 429 (too many requests). Wait an hour, or use the browser fallback.")
        raise Stop(1, f"HTTP {e.code} from {url.split('?')[0]}")
    except urllib.error.URLError as e:
        raise Stop(1, f"Network error: {e.reason}")


def get_player(opener, vid: str) -> dict:
    """Return the Android player response, which carries title, length and caption tracks."""
    html = fetch(
        opener,
        f"https://www.youtube.com/watch?v={vid}&hl=en",
        headers={"User-Agent": DESKTOP_UA, "Accept-Language": "en-US,en;q=0.9", "Cookie": "CONSENT=YES+1; SOCS=CAI"},
    )
    m = re.search(r'"INNERTUBE_API_KEY":\s*"([A-Za-z0-9_-]+)"', html)
    if not m:
        if "g-recaptcha" in html or "confirm you" in html:
            raise Stop(5, "YouTube served a bot check instead of the video page. Use the browser fallback.")
        raise Stop(1, "The video page did not contain an API key; YouTube may have changed its page.")
    body = json.dumps({"context": {"client": ANDROID_CLIENT}, "videoId": vid}).encode()
    player = json.loads(
        fetch(
            opener,
            f"https://www.youtube.com/youtubei/v1/player?key={m.group(1)}&prettyPrint=false",
            data=body,
            headers={"Content-Type": "application/json"},
        )
    )
    status = player.get("playabilityStatus", {})
    if status.get("status") != "OK":
        reason = status.get("reason") or status.get("status") or "unknown reason"
        if "bot" in reason.lower():
            raise Stop(5, f"YouTube asked for a sign-in to prove this is not a bot ({reason}). Use the browser fallback.")
        raise Stop(2, f"Video is not available: {reason}")
    return player


def pick_track(tracks: list, lang: str) -> dict:
    """Prefer human captions, then auto-generated, then a regional variant (en-GB for en)."""
    exact = [t for t in tracks if t.get("languageCode") == lang]
    for t in exact:
        if t.get("kind") != "asr":
            return t
    if exact:
        return exact[0]
    for t in tracks:
        if t.get("languageCode", "").split("-")[0] == lang:
            return t
    available = sorted({t.get("languageCode", "?") for t in tracks})
    raise Stop(3, f"No '{lang}' captions. Available: {', '.join(available) or 'none'}. Rerun with --lang <code>.")


def track_label(track: dict) -> str:
    name = track.get("name", {})
    if "simpleText" in name:
        return name["simpleText"]
    return "".join(r.get("text", "") for r in name.get("runs", [])) or track.get("languageCode", "")


def get_captions(opener, track: dict) -> dict:
    url = track["baseUrl"]
    if "&exp=xpe" in url:
        raise Stop(4, "These captions need a token only a browser can generate. Use the browser fallback.")
    url = re.sub(r"&fmt=[^&]*", "", url) + "&fmt=json3"
    raw = fetch(opener, url, headers={"User-Agent": ANDROID_UA})
    if not raw.strip():
        raise Stop(4, "YouTube returned an empty caption file, which means it wants a browser token. Use the browser fallback.")
    return json.loads(raw)


def json3_text(captions: dict):
    """Join caption segments into one string; also return where the captions end, in seconds."""
    events = captions.get("events", [])
    # Each event is one caption line; human-made captions carry no space between lines
    text = " ".join("".join(seg.get("utf8", "") for seg in e.get("segs", [])) for e in events)
    ends = [e.get("tStartMs", 0) + e.get("dDurationMs", 0) for e in events if e.get("segs")]
    return text, (max(ends) / 1000 if ends else 0)


def read_browser_capture(text_file: str, meta_file: str):
    """Read the fallback's files. The browser tool shows each value as a quoted JSON
    string, so a file of quoted lines is decoded; plain text is taken as it is."""
    raw = Path(text_file).read_text(encoding="utf-8")
    lines = [line.strip() for line in raw.splitlines() if line.strip()]
    if lines and all(line.startswith('"') and line.endswith('"') for line in lines):
        try:
            raw = "".join(json.loads(line) for line in lines)
        except json.JSONDecodeError:
            raise Stop(6, "A slice in the text file is not a complete quoted value. Rewrite the file from the slices.")
    try:
        meta = json.loads(Path(meta_file).read_text(encoding="utf-8"))
        if isinstance(meta, str):
            meta = json.loads(meta)
    except (json.JSONDecodeError, OSError) as e:
        raise Stop(1, f"Could not read the meta file: {e}")
    text = re.sub(r"\s+", " ", raw).strip()
    expected = meta.get("chars")
    if expected and len(text) != expected:
        raise Stop(6, f"The text file has {len(text):,} characters; the browser returned {expected:,}. "
                      "The copy is incomplete or altered: rewrite it from the slices.")
    return text, meta


def paragraphs(text: str) -> str:
    """Re-paragraph caption text: about six sentences or 120 words per paragraph."""
    text = re.sub(r"\s+", " ", text).strip()
    pieces = []
    for sentence in re.split(r"(?<=[.!?])\s+", text):
        words = sentence.split()
        # Older auto-captions have no punctuation at all; cut those into word runs
        for i in range(0, len(words), 120):
            pieces.append(" ".join(words[i:i + 120]))
    out, chunk, count = [], [], 0
    for p in pieces:
        chunk.append(p)
        count += len(p.split())
        if len(chunk) >= 6 or count >= 120:
            out.append(" ".join(chunk))
            chunk, count = [], 0
    if chunk:
        out.append(" ".join(chunk))
    return "\n\n".join(out)


def clock(seconds) -> str:
    s = int(round(float(seconds)))
    h, rest = divmod(s, 3600)
    return f"{h}:{rest // 60:02d}:{rest % 60:02d}" if h else f"{rest // 60}:{rest % 60:02d}"


def output_path(folder: str, title: str) -> Path:
    """'YYYY-MM-DD Title.md', without characters that break file names or Obsidian links; never overwrites."""
    safe = re.sub(r"\s*[:|]\s*", " - ", title)
    safe = re.sub(r'[\\/*?"<>#^\[\]]', "", safe)
    # Emoji and other pictographs: fine in a heading, awkward in a file name
    safe = unicodedata.normalize("NFC", safe)
    safe = "".join(c for c in safe if unicodedata.category(c) not in ("So", "Cs") and c not in "︎️‍")
    safe = re.sub(r"\s+", " ", safe).strip(" .-") or "YouTube Transcript"
    if len(safe) > 100:
        safe = safe[:100].rsplit(" ", 1)[0]
    stem = f"{date.today():%Y-%m-%d} {safe}"
    path = Path(folder) / f"{stem}.md"
    n = 2
    while path.exists():
        path = Path(folder) / f"{stem} ({n}).md"
        n += 1
    return path


def main():
    ap = argparse.ArgumentParser(description="Save a YouTube video's captions as a markdown transcript.")
    ap.add_argument("url", help="YouTube URL or video ID")
    ap.add_argument("output_folder", nargs="?", default=".", help="folder to save into (default: current folder)")
    ap.add_argument("--lang", default="en", help="caption language code (default: en)")
    ap.add_argument("--text-file", help="caption text captured in a browser, instead of fetching it")
    ap.add_argument("--meta-file", help="the browser fallback's step 3 result (required with --text-file)")
    args = ap.parse_args()

    try:
        vid = video_id(args.url)
        if not Path(args.output_folder).is_dir():
            raise Stop(1, f"Output folder does not exist: {args.output_folder}")

        if args.text_file:
            if not args.meta_file:
                raise Stop(1, "--text-file needs --meta-file.")
            text, meta = read_browser_capture(args.text_file, args.meta_file)
            title, channel, length = meta.get("title") or vid, meta.get("channel"), meta.get("lengthSeconds")
            label = f"{meta['captions']}, captured in a browser" if meta.get("captions") else "Captured in a browser"
            covered = meta.get("coveredSeconds")
        else:
            print(f"Fetching captions for {vid}")
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
            player = get_player(opener, vid)
            details = player.get("videoDetails", {})
            title, channel, length = details.get("title") or vid, details.get("author"), details.get("lengthSeconds")
            tracks = player.get("captions", {}).get("playerCaptionsTracklistRenderer", {}).get("captionTracks", [])
            if not tracks:
                raise Stop(3, "This video has no captions (common for live streams and some older uploads).")
            track = pick_track(tracks, args.lang)
            label = track_label(track)
            text, covered = json3_text(get_captions(opener, track))

        title = re.sub(r"\s+", " ", title).strip()
        channel = re.sub(r"\s+", " ", channel).strip() if channel else None
        body = paragraphs(text)
        if not body:
            raise Stop(4, "The caption file had no text. Use the browser fallback.")

        lines = [
            f"# Transcript: {title}",
            "",
            "YouTube captions for this video, cleaned into paragraphs for reading and search. "
            "Auto-generated captions mishear words, so check any quote against the video.",
            "",
            f"- **Video:** https://www.youtube.com/watch?v={vid}",
        ]
        if channel:
            lines.append(f"- **Channel:** {channel}")
        if length:
            lines.append(f"- **Length:** {clock(length)}")
        lines += [f"- **Captions:** {label}", f"- **Retrieved:** {date.today():%Y-%m-%d}", "", "---", "", body, ""]

        path = output_path(args.output_folder, title)
        path.write_text("\n".join(lines), encoding="utf-8")
    except Stop as e:
        print(e, file=sys.stderr)
        sys.exit(e.code)

    print(f"Saved: {path}")
    print(f"{len(body.split()):,} words, {body.count(chr(10) + chr(10)) + 1} paragraphs")
    if covered is not None and length:
        print(f"Captions run to {clock(covered)} of {clock(length)}")


if __name__ == "__main__":
    main()
